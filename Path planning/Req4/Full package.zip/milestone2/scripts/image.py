#!/usr/bin/env python3

# import the required libraries:
from matplotlib import image
import sys
import rospy
import numpy as np 
import cv2 #import openCV to python
#np.set_printoptions(threshold=sys.maxsize)


# Save image in set directory 
img = cv2.imread('/home/ziad/Desktop/fmaze.jpeg')  #Read image 

down_width = 80    
down_height = 80

down_points = (down_width, down_height)



grayImage = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #Convert RGB image to grayscale
cv2.imshow('Original Image', grayImage)




ret, bw_img = cv2.threshold(grayImage,240,255,cv2.THRESH_BINARY) #Convert grayscale image to binary
resized_down = cv2.resize(bw_img, down_points, interpolation= cv2.INTER_LINEAR)
cv2.imshow('threshold', bw_img)
print(type(bw_img))
bw_img = bw_img.astype(np.uint8)
cv2.imshow("Window", resized_down)

h, w= resized_down.shape #get image dimenssions
print('height:', h)
print('width:', w)
print(resized_down)


cv2.waitKey(0) #Maintain output window until user presses a key 
cv2.destroyAllWindows() #Destroying present windows on screen
cv2.imwrite("/home/ziad/Desktop/maze1.png",resized_down)