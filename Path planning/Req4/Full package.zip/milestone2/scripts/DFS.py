#!/usr/bin/env python3
import imghdr
import sys
import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from nav_msgs.msg import Odometry       #import msg data type "Pose" to be subscribed
import math
import numpy as np
import cv2
#np.set_printoptions(threshold=sys.maxsize)  #to show the whole array for debugging
#############
#Golbal Vars
global solverPath
global yaw
global alpha
global beta
global i
#planner points
global x_desired
global y_desired
global theta_desired
#current points
global xPose
global yPose
global theta
#controller param
global linear_v
global angular_v
global Kp
global Kalpha
global Kbeta
#init values
linear_v = 0
angular_v =0
Kyaw=0.2
Kalpha = 0.9
Kbeta = -0.2
xPose = 0
yPose = 0
theta = 0

def quaternion_to_euler(x,y,z,w):
    t0 = +2.0 * (w * x+y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    x_roll = math.atan2(t0, t1)

    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    y_pitch = math.asin(t2)

    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    z_yaw = math.atan2(t3,t4)

    return z_yaw


def callback(Odometry):


    global xPose
    global yPose
    global theta

    xPose = round(Odometry.pose.pose.position.x,3)
    yPose = round(Odometry.pose.pose.position.y,3)
    theta = round(quaternion_to_euler(Odometry.pose.pose.orientation.x,Odometry.pose.pose.orientation.y,Odometry.pose.pose.orientation.z,Odometry.pose.pose.orientation.w),3)

def polar_coordinates():

    global yaw 
    global beta 
    global alpha 
    global x_desired
    global y_desired
    global theta_desired
    global xPose
    global yPose
    global theta
    global x_delta
    global y_delta
    global i

    x_delta = int(x_desired) - xPose
    y_delta = int(y_desired) - yPose

    yaw = np.sqrt((np.square(x_delta))+(np.square(y_delta)))

    gamma = np.arctan2(y_delta,x_delta)

    if gamma < 0 :
        gamma = gamma + (2*np.pi)

    
    
    alpha = gamma - theta
    alpha = (alpha + np.pi) % (2 * np.pi) - np.pi
    beta = - alpha -theta + ((int(theta_desired))*(np.pi/180))
    beta = (beta + np.pi) % (2 * np.pi) - np.pi


    if x_desired < xPose + 0.1 and y_desired < yPose + 0.1:
        i = i + 1
        x_desired = solverPath[i][0]
        y_desired = solverPath[i][1]
        theta_desired = np.arctan2((solverPath[i+1][1]-solverPath[i][1]),(solverPath[i+1][0]-solverPath[i][0]))*(180 /np.pi)
        print(solverPath[i])
    
def control_law():

    global yaw		
    global beta	 
    global alpha		
    global linear_v	
    global angular_v	
    global Kyaw
    global Kalpha
    global Kbeta 
    global x_delta
    global y_delta

    if np.absolute(alpha) < np.pi/2:
        linear_v = Kyaw * yaw
    else:
        linear_v = -Kyaw * yaw

    angular_v = Kalpha * alpha + Kbeta * beta


def Draw_Horizontal(Array,Index1,Index2):   #Draws A horizontal Line from index1 to index2
    Local_Counter = Index1[1]
    while(Local_Counter <= Index2[1]):
        Array[Index1[0],Local_Counter]= 0
        Local_Counter+=1
        
def Draw_Vertical(Array,Index1,Index2):    #Draws A Vertical Line from index1 to index2
    Local_Counter = Index1[0]
    while(Local_Counter <= Index2[0]):
        Array[Local_Counter,Index1[1]]= 0
        Local_Counter+=1
def Draw(Map):    #Draws a Map

    Draw_Horizontal(Map,[0,0],[0,10])
    Draw_Horizontal(Map,[10,0],[10,10])
    Draw_Vertical(Map,[0,0],[10,0])        # EDGES
    Draw_Vertical(Map,[0,10],[10,10])


def BFS(Map,Start,Goal,Direction):  # Direction for CCW -1  for CW 1

    Flag = False # Flag indicating if goal node is found
    
    # Initializing a queue 
    queue = []
    queue.append(Start)

    # Visited Nodes
    Visited = []

    # Parent Node Mapping
    Parents = np.zeros([12,12,2],dtype = int)


    while queue:   # If queue is not empty 

        Node = queue.pop(1)  # Pop first element in the queue

        if Node==Goal:   # Did we reach the goal?
            Flag = True
            break

        Neighbours = get_Neighbours(Node,Direction) # Get neighbours of this node

        for N in Neighbours: # For each neighbour of this node
            if not N in Visited and Map[N[0],N[1]]!=0:   # if this neighbour wasnt visited before and doesnt equal 0 (ie not an obstacle)
                queue.append(N)      # add to the queue
                Visited.append(N)     # add it to the visited
                Parents[N[0],N[1]] = Node  # add its parent node 

    if Flag == False:
        print('Mafesh path :(')

    if Flag == True:
        path = get_Path(Parents,Goal,Start) # this function returns the path to the goal 
        return path

def DFS(Map,Start,Goal,Direction):  # Direction for CCW -1  for CW 1

    Flag = False # Flag indicating if goal node is found
    
    # Initializing a queue 
    stack = []
    stack.append(Start)

    # Visited Nodes
    Visited = []

    # Parent Node Mapping
    Parents = np.zeros([15,15,2],dtype = int)


    while stack:   # If queue is not empty 

        Node = stack.pop(-1)  # Pop first element in the queue

        if Node==Goal:   # Did we reach the goal?
            Flag = True
            break

        Neighbours = get_Neighbours(Node,Direction) # Get neighbours of this node

        for N in Neighbours: # For each neighbour of this node
            if not N in Visited and Map[N[0],N[1]]!=0:   # if this neighbour wasnt visited before and doesnt equal 0 (ie not an obstacle)
                stack.append(N)      # add to the queue
                Visited.append(N)     # add it to the visited
                Parents[N[0],N[1]] = Node  # add its parent node 

    if Flag == False:
        print('Mafesh path :(')

    if Flag == True:
        path = get_Path(Parents,Goal,Start) # this function returns the path to the goal 
        return path

       
    

def get_Path(Parents,Goal,Start):

    path = []
    Node = Goal  # start backward 
    path.append(Goal)
   
    while not np.array_equal(Node, Start):

       path.append(Parents[Node[0],Node[1]])  # add the parent node 
       Node = Parents[Node[0],Node[1]]        # search for the parent of that node 
     
    path.reverse()
    return path

    

def get_Neighbours(Node,Direction):    # Returns neighbours of the parent node   Direction = 1 for Clockwise/ Direction = -1 for CCW 

    Neighbours = []
    
    if Direction==1:
        Neighbours.append([Node[0],Node[1]+1])
        Neighbours.append([Node[0]+1,Node[1]+1])
        Neighbours.append([Node[0]+1,Node[1]])
        Neighbours.append([Node[0]+1,Node[1]-1])
        Neighbours.append([Node[0],Node[1]-1])
        Neighbours.append([Node[0]-1,Node[1]-1])
        Neighbours.append([Node[0]-1,Node[1]])
        Neighbours.append([Node[0]-1,Node[1]+1])
                        
    if Direction==-1:
        Neighbours.append([Node[0],Node[1]+1])
        Neighbours.append([Node[0]-1,Node[1]+1])
        Neighbours.append([Node[0]-1,Node[1]])
        Neighbours.append([Node[0]-1,Node[1]-1])
        Neighbours.append([Node[0],Node[1]-1])
        Neighbours.append([Node[0]+1,Node[1]-1])
        Neighbours.append([Node[0]+1,Node[1]])
        Neighbours.append([Node[0]+1,Node[1]+1])

    return Neighbours

if __name__ == '__main__':     # Main function that is executed 
    global x_desired
    global y_desired
    global theta_desired
    global yaw		
    global beta		 
    global alpha
    global i
    i=1

    img = cv2.imread('/home/ziad/auto_ws/src/milestone2/maze.png')
    grayImage = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, bw_img = cv2.threshold(grayImage,30,255,cv2.THRESH_BINARY)

    Draw(bw_img)
    solverPath = DFS(bw_img, [1,1],[9,9],-1)
    print(solverPath)
    print(bw_img)
    

    rospy.init_node('turtel_control', anonymous=True)
    pub = rospy.Publisher('/cmd_vel',Twist,queue_size=10)

    rate = rospy.Rate(10)


    sub = rospy.Subscriber("odom",Odometry,callback)
    x_desired = solverPath[i][0]
    y_desired = solverPath[i][1]
    theta_desired = np.arctan2((solverPath[i+1][1]-solverPath[i][1]),(solverPath[i+1][0]-solverPath[i][0]))*(180 /np.pi)
    go = Twist()
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    while not rospy.is_shutdown():
        polar_coordinates()
        control_law()
        v = round(linear_v,2)
        w = round(angular_v,2)


        go.linear.x = v  #Linear Velocity
        go.linear.y = 0
        go.linear.z = 0
        go.angular.x = 0
        go.angular.y = 0
        go.angular.z = w #Angular Velocity

        pub.publish(go)
        rate.sleep()

    



